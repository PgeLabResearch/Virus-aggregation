function [N,RR,RD]=AGGupdate(t,N,N0,v,RR,RD,M,betamn)


tt=round(t);

for i=1:M
    %% Birth term due to aggregation
    if i>1 && i<M
        Rab=0;
        for j=1:i
           for k=1:j
               vjk=v(j)+v(k);
               if (v(i-1)<=vjk) && (v(i+1)>=vjk)
                   if j==k
                       deltajk=1;
                   else
                       deltajk=0;
                   end
                   if vjk>=v(i) && vjk<=v(i+1)
                       yita=(v(i+1)-vjk)/(v(i+1)-v(i));
                   end
                   if vjk>=v(i-1) && vjk<=v(i)
                       yita=(vjk-v(i-1))/(v(i)-v(i-1));
                   end
                   Qjk=betamn(j,k);
                   if tt>1
                       Rab=Rab+(1-0.5*deltajk)*yita*Qjk*N(j,tt-1)*N(k,tt-1);
                   else
                       Rab=Rab+(1-0.5*deltajk)*yita*Qjk*N0(j)*N0(k);
                   end
               end
           end
        end
        RR(i,tt)=Rab;
    end
%% Death term due to aggregation
RDa=0;
for k=1:M  %M is the total number of sections
    Qik=betamn(i,k);
    if tt>1
       RDa=RDa+Qik*N(k,tt-1);
    else
        RDa=RDa+Qik*N0(k);
    end 
end
if tt>1
    RDa=RDa*N(i,tt-1);
else
    RDa=RDa*N0(i);
end

RD(i,tt)=RDa; 
N(i,tt)=N(i,tt-1)+(RR(i,tt)-RD(i,tt));
end
end







