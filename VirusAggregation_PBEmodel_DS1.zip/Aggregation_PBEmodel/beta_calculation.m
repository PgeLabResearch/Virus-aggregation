% function [betamn]=betamatrix(v)
clc
clear
close all

M=50;
betamn=zeros(M,M);

r0=210.2453; % nm
v0 = 4/3*pi*(r0)^3; % nm^3
s=1.12;

for i=1:M
    r(i)=r0*s^(i-1);
    v(i)=4*pi/3*r(i)^3;
end

Is = 0.018; %M
pH = 3;
zeta_p=(-41.5*log(pH)+49)/1000; %V

for i=1:M
    tic
    i
    for j=1:M
        betamn(i,j)=betaXDLVO_virus(r(i),r(j),Is,zeta_p);
    end
    toc
end

betamn_virus = betamn;
save betamn_virus_MAT11_pH3

