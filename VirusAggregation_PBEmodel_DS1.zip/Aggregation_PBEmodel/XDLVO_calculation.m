%12/12/2020 sphere to sphere

function [x_h, y_ab, y_dl, y_vdw, y_born, y_xdlvo]=XDLVO_calculation(y_p1,I_s)

%sphere - plate
%parameters
%separation distance
h = 0.25*10^(-9):10^(-12):120*10^(-9);
%Boltzmann constant
kB = 1.381 * 10^(-23);
%temperature
T = 298;
 %the radius of virus (the diameter of MS2 = 25 nm)
r_v = 12.5e-9;


%sphere - sphere
rp1 = r_v; %radius of spherical
rp2 = r_v; %radius of spherical rp1 < or = rp2
Rp = rp2 / rp1;
zeta = h ./ rp1;

%% Lewis acid�base interaction energy
lambda_ab = 1e-9;
h0 = 0.25e-9;
beta1 = 33;%degree
beta3 = 33;%degree
logcK = -7*((cosd(beta1)+cosd(beta3))/2)-18; 
phiAB = -10^(logcK)./(2*pi*h0*lambda_ab);

%  glp = 25.5e-3; %mJ/m^2
%  gln = 25.5e-3;
%  gsp = 0e-3;
%  gsn = 60.3e-3;
%  gcp = 0;
%  gcn = 60.3e-3;

%phiAB = (2 * (glp^0.5))*((gsn^0.5) + (gcn^0.5) - (gln^0.5)) + (2 * (gln^0.5))*((gsp^0.5) + (gcp^0.5) - (glp^0.5)) - (2)*((gsp*gcn)^0.5 + (gsn*gcp)^0.5);
%phiAB = -0.053;
% Lewis acid�base interaction energy
phi_AB = 2*(rp1*rp2/(rp1+rp2))*pi*lambda_ab*phiAB* (exp((h0 - h)./lambda_ab));


%% van der Waals potenial
%the characteristic wavelength of the sphere-plate interactions (m)
lambda = 1e-7;
%hamaker constant
A_123 = 7.5e-21;
%van der Waals potenial
% phi_vdw = - A_123*r_v./(6.*h).*(1+(14.*h./lambda)).^(-1);
% % subplot 512
phi_vdw = - A_123./12.*(Rp./(zeta.^2+zeta.*Rp+zeta)+Rp./(zeta.^2+zeta.*Rp+zeta+Rp)+2.*log((zeta.^2+zeta.*Rp+zeta)./(zeta.^2+zeta.*Rp+zeta+Rp)));


%% Born repulsion energy 
%parameters
sigma =5*10^(-10);
% Born repulsion energy 
%phi_born = A_123.*(sigma.^6)./7560.*((8*r_v + h)./(2*r_v+h).^7 + (6*r_v - h)./h.^7);


phi_born = A_123./(7560*zeta)*(sigma./rp1).^2*...
    ((-4*zeta.^2-14.*(Rp-1)*zeta-6.*(Rp.^2-7.*Rp+1))/(2.*zeta -1 +Rp).^7+...
    (-4*zeta.^2+14*(Rp-1)*zeta-6*(Rp.^2-7*Rp+1))/(2*zeta -1 + Rp).^7+...
    (4*zeta.^2+14*(Rp-1)*zeta+6*(Rp.^2+7*Rp+1))/(2*zeta + 1 + Rp).^7+...
    (4*zeta.^2-14*(Rp-1)*zeta+6*(Rp.^2+7*Rp+1))/(2*zeta -1 - Rp).^7);


%% Double layer potential energy
%parameters

ipxi_r = 78.4;
ipxi_0 = 8.854e-12;
% y_p = -0.040; %V
N_A = 6.02e23;
el = 1.602e-19;

% 
%I_s = 0.015 ; %M
% [y_p,y_s] = potential_pH(I_s);
%y_p1 =0.010;
y_p2 = y_p1;
%y_p2 =0.010;
%k = 1/(3.06e-8);
k= (2*I_s*N_A*1000*el^2/(ipxi_r*ipxi_0*kB*T))^(1/2);

%Double layer potential energy
phi_dl = pi.*ipxi_r.*ipxi_0 .* (rp1.*rp2./(rp1+rp2)) * (2*y_p1*y_p2*log((1+exp(-k.*h))./(1-exp(-k*h)))+(y_p1.^2+y_p2.^2).*log(1-exp(-2.*k.*h)));




%% plot
x_h = h*10^(9);
y_ab = phi_AB/(kB*T);
y_vdw = phi_vdw/(kB*T);
y_dl = phi_dl/(kB*T);
y_born = phi_born/(kB*T);
phi_XDLVO = phi_vdw + phi_dl + phi_AB + phi_born;
y_xdlvo = phi_XDLVO/(kB*T);

end
% y=phi_XDLVO/(kB*T);
% % Size of the figure
% % ==================
% nsubplot=4; 
% ndiagr=2;  %row
% ndiagc=2;  %column
% %ffigure_size_v1(nsubplot,ndiagr)
% figW = 19;     % [cm] figure width - one colum or two-column see journal specifications
% 
% gapL  = (21.59-19.0)/2;     % gap between subplot and left boundary
% gapR  = 0.8+0.5;     % gap between subplot and right boundary
% 
% %gapW  = 21.59-2*9.5-2*gapR; % gap between columns
% gapC  = 0.5;
% %gapB  = (27.9-23.0)/2;      % gap between subplot and  bottom
% gapB = 1.5;
% gapT = 0.5;
% %gapT  = (27.9-23.0)/2;      % gap between subplot and  top
% gapH  = 0.4;      % gap between subplots
% 
% % calculate subplot dimensions from figure size and gaps
% subW  = (figW-gapL-gapR-(ndiagc-1)*gapC)/ndiagc;
% %subW = figW-(gapL+gapR);   % width of plot
% % calculate the subplot height specifying an aspect ratio
% subH = 0.7*subW;
% 
% % calculate figure heigth assuming nsubplot subplots
% figH = gapB + ndiagr*subH + (ndiagr-1)*gapH + gapT;
% %figH = gapB + nsubplot*subH + (nsubplot-1)*gapH + gapT;
% 
% 
% figure('units','centimeters','position',[0 2 figW figH]); 
% 
% i=2;j=2;
% xsub = (gapL+subW*(i-1)+gapC*(i-1))/figW;
% ysub = (gapB+subH*(j-1)+gapH*(j-1))/figH;
% ax = subplot('position',[xsub ysub subW/figW subH/figH]);
% 
% %h(1) = plot(time1./6.6,absorbance1./0.1219,'-r','LineWidth',1);
% %subplot('Position',[0.12 0.65 0.3 0.3]);
% x=h*10^(9);
% plot(x, phi_AB/(kB*T),'color',[1.0 0.4 0.0],'linewidth',1)
% legend('\phi_{AB}')
% set(gca,'yticklabel',[])
% xlabel {}
% set(gca,'xticklabel',[])
% ylabel {\phi/{k_BT}} 
% xlim([0 40])
% ylim([-3 3])
% legend boxoff
% box on
% set(gca, 'FontSize', 12)
% set(gca, 'FontName', 'Times New Roman')
% 
% i=1;j=2;
% xsub = (gapL+subW*(i-1)+gapC*(i-1))/figW;
% ysub = (gapB+subH*(j-1)+gapH*(j-1))/figH;
% ax = subplot('position',[xsub ysub subW/figW subH/figH]);
% 
% %subplot('Position',[0.53 0.65 0.3 0.3]);
% hold on
% plot(x, phi_dl/(kB*T),'color',[0.2 0.4 0.2],'linewidth',1)
% xlim([0 40])
% ylim([-3 3])
% set(gca,'xticklabel',[])
% xlabel {}
% ylabel {\phi/{k_BT}} 
% 
% %legend(strcat('\phi_{dl}, Is=',num2str(i),'mM'))
% legend('\phi_{dl}')
% legend boxoff
% box on
% %ylim([-20 20])
% hold on
% set(gca, 'FontSize', 12)
% set(gca, 'FontName', 'Times New Roman')
% 
% i=2;j=1;
% xsub = (gapL+subW*(i-1)+gapC*(i-1))/figW;
% ysub = (gapB+subH*(j-1)+gapH*(j-1))/figH;
% ax = subplot('position',[xsub ysub subW/figW subH/figH]);
% 
% %subplot('Position',[0.53 0.3 0.3 0.3]);
% plot(x, phi_vdw/(kB*T),'-b','linewidth',1)
% xlim([0 40])
% ylim([-3 3])
% set(gca,'yticklabel',[])
% legend('\phi_{vdw}')
% xlabel {h (nm)}
% ylabel {\phi/{k_BT}} 
% legend boxoff
% box on
% set(gca, 'FontSize', 12)
% set(gca, 'FontName', 'Times New Roman')
% 
% i=1;j=1;
% xsub = (gapL+subW*(i-1)+gapC*(i-1))/figW;
% ysub = (gapB+subH*(j-1)+gapH*(j-1))/figH;
% ax = subplot('position',[xsub ysub subW/figW subH/figH]);
% 
% %subplot('Position',[0.12 0.3 0.3 0.3]);
% hold on
% plot(x, phi_born/(kB*T),'-r','linewidth',1)
% xlim([0 40])
% ylim([-3 3])
% xlabel {h (nm)}
% ylabel {\phi/{k_BT}} 
% legend('\phi_{Born}')
% legend boxoff
% set(gca, 'FontSize', 12)
% set(gca, 'FontName', 'Times New Roman')
% box on
% %% sum of energy from 4 forces
% phi_XDLVO = phi_vdw + phi_dl + phi_AB;
% hold on
% y=phi_XDLVO/(kB*T);
% 
% 
% %%
% % Size of the figure
% % ==================
% nsubplot=1; 
% ndiagr=1;  %row
% ndiagc=1;  %column
% %ffigure_size_v1(nsubplot,ndiagr)
% figW = 12;     % [cm] figure width - one colum or two-column see journal specifications
% 
% gapL  = (21.59-19.0)/2;     % gap between subplot and left boundary
% gapR  = 0.8+0.5;     % gap between subplot and right boundary
% %gapW  = 21.59-2*9.5-2*gapR; % gap between columns
% gapC  = 0.5;
% %gapB  = (27.9-23.0)/2;      % gap between subplot and  bottom
% gapB = 1.5;
% gapT = 0.5;
% %gapT  = (27.9-23.0)/2;      % gap between subplot and  top
% gapH  = 0.4;      % gap between subplots
% % calculate subplot dimensions from figure size and gaps
% subW  = (figW-gapL-gapR-(ndiagc-1)*gapC)/ndiagc;
% %subW = figW-(gapL+gapR);   % width of plot
% % calculate the subplot height specifying an aspect ratio
% subH = 0.8*subW;
% 
% % calculate figure heigth assuming nsubplot subplots
% figH = gapB + ndiagr*subH + (ndiagr-1)*gapH + gapT;
% %figH = gapB + nsubplot*subH + (nsubplot-1)*gapH + gapT;
% 
% % calculate the position of the bottom left corner of each subplot
% % 
% figure('units','centimeters','position',[0 2 figW figH]); 
% % figure(2)
% data1=load('comparsion2.txt');
% data_x=data1(:,1);
% data_y=data1(:,2);
% %plot(data_x,data_y,'ok')
% hold on
% plot([0 50],[0 0],'k--')
% hold on
% plot(x,y,'-k','linewidth',1.5)
% % hold on
% % plot(x, phi_AB/(kB*T),'--k')
% % hold on
% % plot(x, phi_dl/(kB*T),'-')
% % hold on
% % plot(x, phi_vdw/(kB*T),'-b')
% % hold on
% % plot(x, phi_born/(kB*T),'-r')
% 
% xlim([0 40])
% ylim([-3 3])
% xlabel {h (nm)}
% ylabel {Energy, J/{k_BT}} 
% %legend('Literature data','XDLVO model')
% %legend(strcat('\phi_{XDLVO}, Is=',num2str(i),'mM'))
% legend boxoff
% set(gca, 'FontSize', 12)
% set(gca, 'FontName', 'Times New Roman')
% box on
