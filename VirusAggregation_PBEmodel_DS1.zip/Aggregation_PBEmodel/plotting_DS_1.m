clc
clear
close all

figure(1); 
pH = 3;
zeta_p = (-41.5*log(pH)+49)/1000;
% zeta_p = -0.0010;
r0 = 210.2453; % nm, raidus of initial particle
Is = 0.018; % mol/L ionic strength
tmax = 60*60; %seconds
N0 = 5e15; %initial number of partcle 5e10 pfu/mL
load('betamn_virus_MAT11_pH3.mat');
[r, t_MAT11_pH3, N, raverage_MAT11_pH3,Nratio]= aggregation_model(r0,Is,tmax,N0,zeta_p,betamn_virus);

data1=load('MAT11_Ph3.txt'); %experimental data
data_x=data1(:,1);
data_y=data1(:,2);
h1 = plot(data_x,data_y,'o','LineWidth',1.5);
hold on
plot(t_MAT11_pH3, raverage_MAT11_pH3,'-k','LineWidth',1.5);
xlabel {time, min}
ylabel {<r>, nm}

%% XDLVO theory calculation
figure(2)
pH =3;
y_p1 = (-41.5*log(pH)+49)/1000;%-0.0034; %zeta potential, V
I_s = 0.018; %mol/L
% % i=1;j=3;
% % xsub = (gapL+subW*(i-1)+gapC*(i-1))/figW;
% % ysub = (gapB+subH*(j-1)+gapH*(j-1))/figH;
% ax = subplot('position',[xsub ysub subW/figW subH/figH]);
[x_h, y_ab, y_dl, y_vdw, y_born, y_xdlvo]=XDLVO_calculation(y_p1,I_s);
hold on
plot(x_h,y_xdlvo,'-','linewidth',1.5)

xlim([0 20])
ylim([-1 1])
ylabel {V_T, J/{k_BT}}
xlabel {h, nm}

set(gca, 'FontSize', 12)
set(gca, 'FontName', 'Times New Roman')
box on


