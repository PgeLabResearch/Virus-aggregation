function bjk=betaXDLVO_virus(rj,rk,Is,zeta_p)

T=273+25; %K temperature
viscosity=0.001 ; % water viscosity 0.001 Pa.s

%diameter of virus
rj=rj*1e-9; % m, effective radius of the nanoparticle
rk=rk*1e-9; % m, effective radius of the nanoparticle

if rj>rk
    dR=rk/100;
else
    dR=rj/100;
end

Ri=rj+rk+dR;
%Ri=dR;
% etavec=linspace(1e-1,150,1000); % nm, distance between the surface of two interacting particles

% van der Waals energy
% --------------------
kBT=1.38*10^(-23)*T; % m2 kg s-2 K-1 * K
Ha=7.5e-21; % J = N*m for microscopic bodies of composition

% Electrostatic energy 
% --------------------
epsr=78.4; % (-) at 20oC, relative permittivity of water,
eps0=8.854*1e-12; % F/m, vacuum permittivity
NA=6.0221367*10^(23); % mol-1
elec=1.602176634*10^(-19); % C elementary charge

% z=1;
% conc=0.001; % % mole/kg
% I = 0.5*(conc*z^2); % mole/kg
%[y_p,y_s] = potential_pH(Is);
I=Is*1000;
%kappa=1/sqrt(epsr*eps0*kBT/(2*NA*elec^2*I))/1e-9;
kappa=sqrt((2*NA*elec^2*I)/(epsr*eps0*kBT));
psi=zeta_p;
%psi=y_p;
%psi=psi*1e-3; % V, surface potential

% Born interaction energy
sigma = 0.5e-9; %nm

% Acid-base interaction energy
% ---------------
lambda_ab = 1e-9; %m
h0 = 30e-9; %m
beta1 = 40;%degree
beta3 = 40;%degree
logcK = -7*((cosd(beta1)+cosd(beta3))/2)-18; 
phiAB = -10^(logcK)./(2*pi*h0*lambda_ab);

Rp = rj / rk;
zeta = Ri / rk;
%van Dew force
VA = - Ha/12*(Rp/(zeta^2+zeta*Rp+zeta) + Rp/(zeta^2+zeta*Rp+zeta+Rp)+2.*log((zeta^2+zeta*Rp+zeta)/(zeta^2+zeta*Rp+zeta+Rp)));
%double layer electro
VE = pi*epsr*eps0*(rj*rk/(rj+rk))*(2*psi^2*log((1+exp(-kappa*Ri))./(1-exp(-kappa*Ri)))+(psi^2+psi^2).*log(1-exp(-2*kappa*Ri)));

%Born 
VB = Ha./(7560*zeta).*(sigma./rj).^2*...
    ((-4*zeta^2-14*(Rp-1)*zeta-6*(Rp^2-7*Rp+1))/(2*zeta -1 +Rp)^7+...
    (-4*zeta^2+14*(Rp-1)*zeta-6*(Rp^2-7*Rp+1))/(2*zeta -1 + Rp)^7+...
    (4*zeta^2+14*(Rp-1)*zeta+6*(Rp^2+7*Rp+1))/(2*zeta + 1 + Rp)^7+...
    (4*zeta^2-14*(Rp-1)*zeta+6*(Rp^2+7*Rp+1))/(2*zeta -1 - Rp)^7);
%acid-base
Vab=2*pi*(rk*rj/(rk+rj))*lambda_ab*phiAB* (exp((h0 - Ri)./lambda_ab));

VT=VA+VE+Vab+VB;

i=0;
Wjk=0;
while ((abs(VT/kBT)>1e-14)|(abs(VA/kBT)>1e-14))
Wjk=Wjk+(rj+rk)*exp(VT/kBT)/Ri/Ri*dR;
Ri=Ri+dR;

Rp = rj / rk;
zeta = Ri / rk;
%van Dew force
VA = - Ha/12*(Rp/(zeta^2+zeta*Rp+zeta)+Rp/(zeta^2+zeta*Rp+zeta+Rp)+2*log((zeta^2+zeta*Rp+zeta)/(zeta^2+zeta*Rp+zeta+Rp)));
%double layer electro
VE = pi*epsr*eps0*(rj*rk/(rj+rk))*(2*psi^2*log((1+exp(-kappa*Ri))./(1-exp(-kappa*Ri)))+(psi^2+psi^2).*log(1-exp(-2*kappa*Ri)));

%Born 
VB = Ha./(7560*zeta)*(sigma./rj).^2*...
    ((-4*zeta^2-14*(Rp-1)*zeta-6*(Rp^2-7*Rp+1))/(2*zeta -1 +Rp)^7+...
    (-4*zeta^2+14*(Rp-1)*zeta-6*(Rp^2-7*Rp+1))/(2*zeta -1 + Rp)^7+...
    (4*zeta^2+14*(Rp-1)*zeta+6*(Rp^2+7*Rp+1))/(2*zeta + 1 + Rp)^7+...
    (4*zeta^2-14*(Rp-1)*zeta+6*(Rp^2+7*Rp+1))/(2*zeta -1 - Rp)^7);
%acid-base

Vab=2*pi*(rk*rj/(rk+rj))*lambda_ab*phiAB* (exp((h0 - Ri)./lambda_ab));

VT1=VT;
VT=VA+VE+Vab+VB;

if ((abs(abs(VT/kBT)-abs(VT1/kBT)))/abs(VT1/kBT)*1e16)<1
    break
end
end
bjk=2*kBT/3/viscosity/Wjk*(rj+rk)*(1/rj+1/rk);

if (bjk == Inf)
    bjk;
end

end

