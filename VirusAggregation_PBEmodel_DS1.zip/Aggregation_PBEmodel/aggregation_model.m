
function [r, t, N, raverage,Nratio]= aggregation_model(r0,Is,tmax,N0,zeta_p,betamn_virus)

M=50;
betamn=zeros(M,M);
v0 = 4/3*pi*(r0)^3; % nm^3
s=1.12;

for i=1:M
    r(i)=r0*s^(i-1);
    v(i)=4*pi/3*r(i)^3;
end

betamn = betamn_virus;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
dt=1;


M=50;
v0 = 4/3*pi*(r0)^3; % nm^3
s=1.12;

for i=1:M
    %r(i)=r0+3*(i-1);
    r(i)=r0*s^(i-1);
    v(i)=4*pi/3*r(i)^3;
end

% n=zeros(M,tmax);
N=zeros(M,tmax);
N(1,1)=N0;

RR=zeros(M,tmax);
RD=zeros(M,tmax);  
RRD=zeros(M,tmax); 
NS=zeros(tmax,1);
Nratio=zeros(tmax,1);

for i=1:M
    NS(1)=NS(1)+N(i,1);
end


for t=2:tmax
[N,RR,RD]=AGGupdate(t,N,N(:,1),v,RR,RD,M,betamn);
for i=1:M
    NS(t)=NS(t)+N(i,t);
end
t
Nratio(t)=NS(t)/NS(1);
end

%% kinetics size incresing
nsum=zeros(tmax,1);
vaverage=zeros(tmax,1);
vsum=zeros(tmax,1);
vmax=zeros(tmax,1);
found = true;
for t=1:tmax
    found = true;
    for i=1:M
        nsum(t)=nsum(t)+N(i,t);
        vsum(t)=vsum(t)+N(i,t)*v(i);
       
        %if (found && i < M && N(i + 1, t) < 1)
        if (found && i < M && N(i + 1, t) < 1 && N(i + 1, t) > 0)
            vmax(t) = v(i);
            found = false;
        end
    end
    vaverage(t)=vsum(t)/nsum(t);
end
raverage=(3*vaverage/4/pi).^(1/3);
tt1 = 1:1:tmax;
t=tt1./60;

end

